# -*- coding: utf-8 -*-
from __future__ import unicode_literals, absolute_import, print_function

from .endpoint import OAuth2Endpoint
